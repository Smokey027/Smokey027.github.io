/**
 * NextActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.0
 * Purpose: Provides the user interface for the next activity in the app.
 * Handles navigation and interaction with the bottom navigation bar.
 * Known Issues: None identified.
 * Functionality:
 * - Allows navigation back to MainActivity using a back button.
 * - Provides interaction with bottom navigation items.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NextActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        // Set up the action bar with a back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Find the back button and set an OnClickListener
        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> {
            // Finish the current activity and go back to MainActivity
            finish();
        });

        // Set up bottom navigation with item selection handling
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                Toast.makeText(NextActivity.this, "Home selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_events) {
                Toast.makeText(NextActivity.this, "Events selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_profile) {
                Toast.makeText(NextActivity.this, "Profile selected", Toast.LENGTH_SHORT).show();
                return true;
            } else {
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Handle the back button click
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}




