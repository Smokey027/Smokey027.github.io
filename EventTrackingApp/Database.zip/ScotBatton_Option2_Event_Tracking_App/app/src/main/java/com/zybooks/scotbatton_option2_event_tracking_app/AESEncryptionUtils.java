/**
 * AESEncryption.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Provides utility methods for AES encryption and decryption
 * Provides event details title, date, and location.
 * Known Issues:
 * Error handling is basic and needs more validation and feedback
 * Functionality:
 * Generate a 256-bit AES encryption key.
 * Encrypts data using AES/CBC/PKCS5Padding.
 * Decrypts data using AES/CBC/PKCS5Padding.
 */
package com.zybooks.scotbatton_option2_event_tracking_app;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.security.SecureRandom;

class AESEncryptionUtils {

    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    // Method to generate a new AES encryption key
    public static SecretKey generateAESKey() throws Exception {
        // Create a KeyGenerator instance
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        // Initialize key size to 256 bits
        keyGenerator.init(256);
        // Generate and return secret key
        return keyGenerator.generateKey();
    }
    // Method to encrypt data using AES Encryption
    public static String encrypt(String data, SecretKey key) throws Exception {
        // Get a cipher instance for algorithm
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        // Create byte array for initializing vector
        byte[] iv = new byte[16];
        // Use SecureRandom to generate random bytes for IV
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        // Create IvParameterSpec with generated IV
        IvParameterSpec ivParams = new IvParameterSpec(iv);
        // Initialize the cipher
        cipher.init(Cipher.ENCRYPT_MODE, key, ivParams);
        // Encrypt data
        byte[] encryptedData = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        // Concatenate IV and encrypted data
        byte[] combined = new byte[iv.length + encryptedData.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(encryptedData, 0, combined, iv.length, encryptedData.length);
        // Encode combined byte array to Base64
        return Base64.getEncoder().encodeToString(combined);
    }
    // Method to decrypt data using AES encryption
    public static String decrypt(String encryptedData, SecretKey key) throws Exception {
        // Decode the Base64 encoded string
        byte[] combined = Base64.getDecoder().decode(encryptedData);
        // Extract IV from byte array
        byte[] iv = new byte[16];
        // Extract encrypted data
        byte[] encryptedBytes = new byte[combined.length - iv.length];
        System.arraycopy(combined, 0, iv, 0, iv.length);
        System.arraycopy(combined, iv.length, encryptedBytes, 0, encryptedBytes.length);
        // Get cipher instance
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        // Create IvParameterSpec
        IvParameterSpec ivParams = new IvParameterSpec(iv);
        // Initialize cipher in decryption mode
        cipher.init(Cipher.DECRYPT_MODE, key, ivParams);
        // Decrypt the data
        byte[] decryptedData = cipher.doFinal(encryptedBytes);
        // Convert decrypted byte array into string
        return new String(decryptedData, StandardCharsets.UTF_8);
    }
}


