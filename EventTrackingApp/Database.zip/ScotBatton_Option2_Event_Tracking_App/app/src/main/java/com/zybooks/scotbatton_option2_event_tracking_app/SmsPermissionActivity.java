/**
 * SmsPermissionActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.0
 * Purpose: Manages user login and handles SMS permission requests.
 * Known Issues: None identified.
 * Functionality:
 * - Captures and validates user login credentials.
 * - Encrypts password before checking against stored credentials.
 * - Handles SMS permission requests (implementation pending).
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import javax.crypto.SecretKey;

public class SmsPermissionActivity extends AppCompatActivity {

    private EditText usernameEditText; // Input field for username
    private EditText passwordEditText; // Input field for password
    private DataBase dbHelper; // Database helper for user authentication
    private SecretKey secretKey; // Secret key for password encryption

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        // Button to initiate login
        Button loginButton = findViewById(R.id.loginButton);
        // Button to request SMS permissions
        Button requestPermissionButton = findViewById(R.id.requestPermissionButton);
        dbHelper = new DataBase(this);

        // Initialize the secret key for encryption
        try {
            secretKey = AESEncryptionUtils.generateAESKey();
        } catch (Exception e) {
            Toast.makeText(this, "Error generating encryption key", Toast.LENGTH_SHORT).show();
            return;
        }

        // Set up login button click listener
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();
            handleLogin(username, password);
        });

        // Set up request permission button click listener
        requestPermissionButton.setOnClickListener(v -> {
            // Handle SMS permission request (implementation pending)
        });
    }

    /**
     * Handles user login by validating credentials and navigating to the next activity upon success.
     *
     * @param username The username entered by the user.
     * @param password The password entered by the user.
     */
    private void handleLogin(String username, String password) {
        Log.d("SmsPermissionActivity", "Attempting login with username: " + username);

        try {
            // Encrypt the password before checking
            String encryptedPassword = AESEncryptionUtils.encrypt(password, secretKey);
            if (dbHelper.checkUser(username, encryptedPassword)) {
                Log.d("SmsPermissionActivity", "Login successful, starting new activity.");
                Intent intent = new Intent(SmsPermissionActivity.this, NextActivity.class);
                startActivity(intent);
                finish();
            } else {
                Log.d("SmsPermissionActivity", "Login failed, showing error message.");
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Failed to encrypt password", Toast.LENGTH_SHORT).show();
        }
    }
}









