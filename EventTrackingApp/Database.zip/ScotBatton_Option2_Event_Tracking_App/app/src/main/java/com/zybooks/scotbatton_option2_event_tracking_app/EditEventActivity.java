/**
 * EditEventActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Allows users to edit existing events by retrieving event details.
 * Updates the event details in the database.
 * Known Issues:
 * Event retrieval could be optimized for better performance.
 * Functionality:
 * - Loads event details into editable fields.
 * - Updates the database with new event data upon saving.
 * - Uses intents to pass event IDs for data retrieval.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditEventActivity extends BaseActivity {

    // UI components for editing event details
    private EditText titleEditText;    // EditText for event title
    private EditText dateEditText;     // EditText for event date
    private EditText locationEditText; // EditText for event location
    private DataBase dbHelper;         // Database helper instance for database operations
    private int eventId;               // ID of the event being edited

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        // Initialize the database helper
        dbHelper = new DataBase(this);

        // Initialize UI components
        titleEditText = findViewById(R.id.titleEditText);
        dateEditText = findViewById(R.id.dateEditText);
        locationEditText = findViewById(R.id.locationEditText);
        // Button to save the edited event
        Button saveEventButton = findViewById(R.id.saveEventButton);

        // Retrieve the event ID from the intent
        Intent intent = getIntent();
        eventId = intent.getIntExtra("event_id", -1);

        // Load event details into UI components
        Event event = getEventDetails(eventId);
        if (event != null) {
            titleEditText.setText(event.getTitle());
            dateEditText.setText(event.getDate());
            locationEditText.setText(event.getLocation());
        }

        // Set click listener for the save button
        saveEventButton.setOnClickListener(v -> {
            // Capture and trim input data from EditText fields
            String title = titleEditText.getText().toString().trim();
            String date = dateEditText.getText().toString().trim();
            String location = locationEditText.getText().toString().trim();

            // Check if all input fields are filled
            if (!title.isEmpty() && !date.isEmpty() && !location.isEmpty()) {
                // Update the event in the database
                dbHelper.updateEvent(eventId, title, date, location);
                // Notify the user that the event has been updated
                Toast.makeText(EditEventActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                // Navigate back to the EventListActivity
                Intent intent1 = new Intent(EditEventActivity.this, EventListActivity.class);
                startActivity(intent1);
                // Finish the current activity
                finish();
            } else {
                // Show error message if any input field is empty
                Toast.makeText(EditEventActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Retrieves the details of a specific event by its ID.
     * @param eventId The ID of the event to retrieve.
     * @return An Event object containing the event details, or null if not found.
     */
    private Event getEventDetails(int eventId) {
        Cursor cursor = dbHelper.getAllEvents();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("event_id"));
                if (id == eventId) {
                    // Extract event details from the cursor
                    String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                    String location = cursor.getString(cursor.getColumnIndexOrThrow("location"));
                    cursor.close();
                    return new Event(eventId, title, date, location);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
}



