/**
 * AddEventActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: September 22, 2024
 * Version 1.1
 * Purpose: Provides user interface and logic for adding new events to app.
 * Provides event details title, date, and location.
 * Known Issues:
 * Error handling is basic and needs more validation and feedback
 * Functionality:
 * Initializes UI components for event input
 * Validates input fields and saves events to database
 * Navigates back to the event list after saving.
 */
package com.zybooks.scotbatton_option2_event_tracking_app;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddEventActivity extends BaseActivity {

    private EditText titleEditText;    // EditText for event title
    private EditText dateEditText;     // EditText for event date
    private EditText locationEditText; // EditText for event location
    private DataBase dbHelper;          // Database helper instance for database operations
    // SharedPreferences for language settings

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialize the database helper and UI components
        dbHelper = new DataBase(this);
        titleEditText = findViewById(R.id.titleEditText);
        dateEditText = findViewById(R.id.dateEditText);
        locationEditText = findViewById(R.id.locationEditText);
        // Button to save the event
        Button saveEventButton = findViewById(R.id.saveEventButton);

        // Set click listener for the save button
        saveEventButton.setOnClickListener(v -> {
            String title = titleEditText.getText().toString().trim();
            String date = dateEditText.getText().toString().trim();
            String location = locationEditText.getText().toString().trim();

            // Input validation
            if (title.isEmpty()) {
                titleEditText.setError("Title cannot be empty");
                return;
            }
            if (date.isEmpty()) {
                dateEditText.setError("Date cannot be empty");
                return;
            }
            if (location.isEmpty()) {
                locationEditText.setError("Location cannot be empty");
                return;
            }

            // Show progress dialog
            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Adding event...");
            progressDialog.setCancelable(false);
            progressDialog.show();

            // Validate date format
            if (!isValidDate(date)) {
                progressDialog.dismiss();
                Toast.makeText(this, "Invalid date format. Use YYYY-MM-DD.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add event to the database
            try {
                dbHelper.addEvent(title, date, location);
                progressDialog.dismiss();
                Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show();
                clearFields();
                startActivity(new Intent(AddEventActivity.this, EventListActivity.class));
                finish(); // Navigate back or update the UI
            } catch (Exception e) {
                progressDialog.dismiss();
                Toast.makeText(this, "Failed to add event. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }
    // Method to validate if data string is in correct format
    private boolean isValidDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        sdf.setLenient(false);
        try {
            Date parsedDate = sdf.parse(date);
            return parsedDate != null;
        } catch (ParseException e) {
            return false;
        }
    }
    // Method to clear text fields in the UI
    private void clearFields() {
        titleEditText.setText("");
        dateEditText.setText("");
        locationEditText.setText("");
    }
}




