/**
 * DataBase.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Manages SQLite database for the application.
 * Handles table creation and CRUD operations for users and events.
 * Known Issues:
 * Error logging could be improved for better debugging.
 * Functionality:
 * - Defines database schema and manages database lifecycle.
 * - Provides methods for adding, updating, deleting, and retrieving users and events.
 * - Implements password hashing for user security.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;
import org.mindrot.jbcrypt.BCrypt;

public class DataBase extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names for users
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Table and column names for events
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_TITLE = "title";
    public static final String COLUMN_EVENT_DATE = "date";
    public static final String COLUMN_EVENT_LOCATION = "location";

    // Table for user-event relationships
    public static final String TABLE_USER_EVENTS = "user_events";
    public static final String COLUMN_USER_ID = "user_id";

    private final Context context;

    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // SQL statement to create users table
            String createUsersTable = "CREATE TABLE " + TABLE_USERS +
                    "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL)";
            db.execSQL(createUsersTable);

            // SQL statement to create events table
            String createEventsTable = "CREATE TABLE " + TABLE_EVENTS +
                    "(" + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EVENT_TITLE + " TEXT NOT NULL, " +
                    COLUMN_EVENT_DATE + " TEXT NOT NULL, " +
                    COLUMN_EVENT_LOCATION + " TEXT NOT NULL)";
            db.execSQL(createEventsTable);

            // SQL statement to create user-events table
            String createUserEventsTable = "CREATE TABLE " + TABLE_USER_EVENTS +
                    "(" + COLUMN_USER_ID + " INTEGER NOT NULL, " +
                    COLUMN_EVENT_ID + " INTEGER NOT NULL, " +
                    "PRIMARY KEY (" + COLUMN_USER_ID + ", " + COLUMN_EVENT_ID + "), " +
                    "FOREIGN KEY (" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + ") ON DELETE CASCADE, " +
                    "FOREIGN KEY (" + COLUMN_EVENT_ID + ") REFERENCES " + TABLE_EVENTS + "(" + COLUMN_EVENT_ID + ") ON DELETE CASCADE)";
            db.execSQL(createUserEventsTable);

            // Create indexes for optimization
            db.execSQL("CREATE INDEX idx_users_username ON " + TABLE_USERS + "(" + COLUMN_USERNAME + ")");
            db.execSQL("CREATE INDEX idx_events_date ON " + TABLE_EVENTS + "(" + COLUMN_EVENT_DATE + ")");
            db.execSQL("CREATE INDEX idx_user_events_user_id ON " + TABLE_USER_EVENTS + "(" + COLUMN_USER_ID + ")");
            db.execSQL("CREATE INDEX idx_user_events_event_id ON " + TABLE_USER_EVENTS + "(" + COLUMN_EVENT_ID + ")");
            db.execSQL("CREATE UNIQUE INDEX idx_events_unique ON " + TABLE_EVENTS + "(" + COLUMN_EVENT_TITLE + ", " + COLUMN_EVENT_DATE + ", " + COLUMN_EVENT_LOCATION + ")");
        } catch (SQLException e) {
            Log.e("Database Error", "Error creating tables: " + e.getMessage());
            Toast.makeText(context, "Database creation failed!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            // Drop existing tables and recreate them on upgrade
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_EVENTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
            onCreate(db);
        } catch (SQLException e) {
            Log.e("Database Error", "Error upgrading database: " + e.getMessage());
            Toast.makeText(context, "Database upgrade failed!", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to add a new user with hashed password
    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // Hash the password for security
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, hashedPassword);

        try {
            db.insertOrThrow(TABLE_USERS, null, values);
            Toast.makeText(context, "User added successfully!", Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            Log.e("Database Error", "Error adding user: " + e.getMessage());
            Toast.makeText(context, "Failed to add user!", Toast.LENGTH_SHORT).show();
        } finally {
            db.close();
        }
    }

    // Method to check if a user's credentials are valid
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        boolean isValid = false;

        try {
            // Query to retrieve the stored password for the given username
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_PASSWORD}, COLUMN_USERNAME + "=?",
                    new String[]{username}, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                String storedPassword = cursor.getString(0);
                // Check the password against the stored hashed password
                isValid = BCrypt.checkpw(password, storedPassword);
            }
        } catch (SQLException e) {
            Log.e("Database Error", "Error checking user: " + e.getMessage());
            Toast.makeText(context, "Error checking user credentials!", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return isValid;
    }

    // Method to add a new event to the database
    public void addEvent(String title, String date, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_TITLE, title);
        values.put(COLUMN_EVENT_DATE, date);
        values.put(COLUMN_EVENT_LOCATION, location);

        try {
            db.insertOrThrow(TABLE_EVENTS, null, values);
            Toast.makeText(context, "Event added successfully!", Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            Log.e("Database Error", "Error adding event: " + e.getMessage());
            Toast.makeText(context, "Failed to add event!", Toast.LENGTH_SHORT).show();
        } finally {
            db.close();
        }
    }

    // Method to delete an event by its ID
    public void deleteEvent(int eventId) {
        try (SQLiteDatabase db = this.getWritableDatabase()) {
            // Delete the event with the specified ID
            int rowsAffected = db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            if (rowsAffected > 0) {
                Toast.makeText(context, "Event deleted successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Event not found!", Toast.LENGTH_SHORT).show();
            }
        } catch (SQLException e) {
            Log.e("Database Error", "Error deleting event: " + e.getMessage());
            Toast.makeText(context, "Failed to delete event!", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to retrieve all events from the database
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            // Query to get all events ordered by date
            cursor = db.query(TABLE_EVENTS, null, null, null, null, null, COLUMN_EVENT_DATE + " ASC");
        } catch (SQLException e) {
            Log.e("Database Error", "Error retrieving events: " + e.getMessage());
            Toast.makeText(context, "Failed to retrieve events!", Toast.LENGTH_SHORT).show();
        }
        return cursor;
    }

    // Method to retrieve events with pagination
    public Cursor getEventsPaginated(int offset, int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            // Query to get events with pagination
            cursor = db.query(TABLE_EVENTS, null, null, null, null, null, COLUMN_EVENT_DATE + " ASC", offset + "," + limit);
        } catch (SQLException e) {
            Log.e("Database Error", "Error retrieving paginated events: " + e.getMessage());
            Toast.makeText(context, "Failed to retrieve events!", Toast.LENGTH_SHORT).show();
        }
        return cursor;
    }

    // Method to update an existing event
    public void updateEvent(int eventId, String title, String date, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_TITLE, title);
        values.put(COLUMN_EVENT_DATE, date);
        values.put(COLUMN_EVENT_LOCATION, location);

        try {
            // Update the event with the specified ID
            int rowsAffected = db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            if (rowsAffected > 0) {
                Toast.makeText(context, "Event updated successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Event not found!", Toast.LENGTH_SHORT).show();
            }
        } catch (SQLException e) {
            Log.e("Database Error", "Error updating event: " + e.getMessage());
            Toast.makeText(context, "Failed to update event!", Toast.LENGTH_SHORT).show();
        } finally {
            db.close();
        }
    }
}






