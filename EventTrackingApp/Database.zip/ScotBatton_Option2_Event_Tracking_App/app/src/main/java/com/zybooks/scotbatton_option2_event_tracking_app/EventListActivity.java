/**
 * EventListActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Display a list of events in a RecyclerView.
 * This allows users to view and delete events.
 * It interacts with the database to fetch and manipulate data.
 * Known Issues: Enhance UI with animations for item changes.
 * Functionality:
 * - Initializes database and RecyclerView.
 * - Binds event data with adapter.
 * - Handles item clicks for viewing and long clicks for deleting events.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.MergeCursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class EventListActivity extends BaseActivity {

    private DataBase dbHelper;             // Database helper for managing event data
    private EventAdapter eventAdapter;     // Adapter for binding event data to RecyclerView
    private Cursor cursor;                 // Cursor for navigating through event data
    private int currentPage = 0;           // Current page for pagination
    private final int pageSize = 20;       // Number of events to load per page
    private boolean isLoading = false;     // Flag to prevent multiple simultaneous loads

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        dbHelper = new DataBase(this);
        cursor = dbHelper.getEventsPaginated(currentPage * pageSize, pageSize); // Load initial data

        setupRecyclerView();
    }

    /**
     * Sets up the RecyclerView with a layout manager, item animator, and adapter.
     */
    private void setupRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.eventRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        eventAdapter = new EventAdapter(this, cursor);
        recyclerView.setAdapter(eventAdapter);

        // Add scroll listener for pagination
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                if (!isLoading && layoutManager != null && layoutManager.findLastCompletelyVisibleItemPosition() == eventAdapter.getItemCount() - 1) {
                    // Load more items when the last item is visible
                    loadMoreEvents();
                }
            }
        });
    }

    /**
     * Loads more events from the database for pagination.
     */
    private void loadMoreEvents() {
        isLoading = true;
        currentPage++;
        Cursor newCursor = dbHelper.getEventsPaginated(currentPage * pageSize, pageSize);
        if (newCursor.getCount() > 0) {
            eventAdapter.appendCursor(newCursor); // Method to append new cursor data
        }
        isLoading = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshEventList();
    }

    /**
     * Refreshes the event list by reloading data from the database.
     */
    private void refreshEventList() {
        Cursor newCursor = dbHelper.getEventsPaginated(0, pageSize);
        if (cursor != null) {
            cursor.close();
        }
        cursor = newCursor;
        eventAdapter.swapCursor(cursor);
        currentPage = 0; // Reset to the first page
    }

    @Override
    protected void onPause() {
        if (cursor != null) {
            cursor.close();
        }
        dbHelper.close();
        super.onPause();
    }

    /**
     * Adapter class for binding event data to RecyclerView items.
     */
    private class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

        private final Context context; // Context of the activity
        private Cursor cursor;         // Cursor for event data

        public EventAdapter(Context context, Cursor cursor) {
            this.context = context;
            this.cursor = cursor;
        }

        /**
         * Swaps the current cursor with a new one and refreshes the adapter.
         *
         * @param newCursor The new cursor with updated data.
         */
        public void swapCursor(Cursor newCursor) {
            if (cursor != null) {
                cursor.close();
            }
            cursor = newCursor;
            notifyDataSetChanged();
        }

        /**
         * Appends new cursor data to the existing data set.
         *
         * @param newCursor The cursor containing new data.
         */
        public void appendCursor(Cursor newCursor) {
            if (newCursor != null && newCursor.getCount() > 0) {
                int oldCount = cursor.getCount();
                Cursor mergedCursor = new MergeCursor(new Cursor[]{cursor, newCursor}); // Use MergeCursor if using Android API
                cursor.close(); // Close old cursor
                cursor = mergedCursor;
                notifyItemRangeInserted(oldCount, newCursor.getCount());
            }
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.event_info, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            if (cursor.moveToPosition(position)) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_TITLE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_DATE));
                String location = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_LOCATION));

                holder.titleTextView.setText(title);
                holder.dateTextView.setText(date);
                holder.locationTextView.setText(location);
            }
        }

        @Override
        public int getItemCount() {
            return cursor != null ? cursor.getCount() : 0;
        }

        /**
         * ViewHolder class for holding the views for each event item.
         */
        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView titleTextView;    // TextView for displaying the event title
            public TextView dateTextView;     // TextView for displaying the event date
            public TextView locationTextView; // TextView for displaying the event location

            public ViewHolder(View itemView) {
                super(itemView);
                titleTextView = itemView.findViewById(R.id.titleTextView);
                dateTextView = itemView.findViewById(R.id.dateTextView);
                locationTextView = itemView.findViewById(R.id.locationTextView);

                itemView.setOnClickListener(v -> {
                    int position = getAdapterPosition();
                    if (cursor.moveToPosition(position)) {
                        String eventName = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_TITLE));
                        Toast.makeText(context, eventName, Toast.LENGTH_SHORT).show();
                    }
                });

                itemView.setOnLongClickListener(v -> {
                    int position = getAdapterPosition();
                    if (cursor.moveToPosition(position)) {
                        final long deleteId = cursor.getLong(cursor.getColumnIndexOrThrow(DataBase.COLUMN_ID));
                        new AlertDialog.Builder(EventListActivity.this)
                                .setTitle("Delete Event")
                                .setMessage("Are you sure you want to delete this event?")
                                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                                    dbHelper.deleteEvent((int) deleteId);
                                    refreshEventList(); // Refresh the list after deletion
                                })
                                .setNegativeButton(android.R.string.no, null)
                                .show();
                    }
                    return true;
                });
            }
        }
    }
}










