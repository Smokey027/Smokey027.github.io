/**
 * KeystoreUtil.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: September 22, 2024
 * Version 1.0
 * Purpose: Utility class for managing cryptographic keys using Android's KeyStore.
 * This class provides methods to generate and retrieve a secret key for encryption and decryption.
 * Known Issues: None identified.
 * Functionality:
 * - Generates a new AES secret key if it does not exist.
 * - Retrieves the secret key from the Android KeyStore.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class KeystoreUtil {

    private static final String KEY_ALIAS = "myKeyAlias";          // Alias for the key in the KeyStore
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore"; // Name of the Android KeyStore

    /**
     * Retrieves a secret key from the Android KeyStore. If the key does not exist, it generates a new one.
     *
     * @return SecretKey The secret key used for encryption and decryption.
     * @throws Exception If there are issues accessing the KeyStore or generating the key.
     */
    public static SecretKey getSecretKey() throws Exception {
        // Get the instance of the Android KeyStore
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null); // Load the KeyStore with default parameters

        // Check if the key alias already exists in the KeyStore
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            // Initialize a KeyGenerator for AES algorithm within the Android KeyStore
            KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);

            // Define the key generation parameters
            KeyGenParameterSpec keyGenParameterSpec = new KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT) // Set purposes for the key
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC) // Set block mode
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7) // Set padding
                    .build();

            // Initialize the KeyGenerator with the specified parameters
            keyGenerator.init(keyGenParameterSpec);
            // Generate the secret key
            keyGenerator.generateKey();
        }

        // Retrieve and return the secret key from the KeyStore
        return ((SecretKey) keyStore.getKey(KEY_ALIAS, null));
    }
}


