/**
 * RegistrationActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Allows new users to register by entering username and password stored in database.
 * Known Issues:
 * - Password strength validation is minimal.
 * Functionality:
 * - Captures and validates user input.
 * - Stores new user credentials in the database.
 * - Includes button animation for improved user interaction.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class RegistrationActivity extends BaseActivity {

    private EditText usernameEditText; // Input field for username
    private EditText passwordEditText; // Input field for password
    private DataBase dbHelper; // Database helper for storing user credentials

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLocale(); // Set the locale based on saved preferences
        setContentView(R.layout.activity_registration);

        dbHelper = new DataBase(this);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        // Button to submit registration
        Button registerButton = findViewById(R.id.registerButton);
        // Button to go back to the previous activity
        Button backButton = findViewById(R.id.backButton); // Initialize back button

        // Back button implementation
        backButton.setOnClickListener(v -> {
            finish(); // Close the current activity and go back to the previous one
        });

        // Register button implementation with animation and validation
        registerButton.setOnClickListener(v -> v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).withEndAction(() ->
                v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).withEndAction(() -> {
                    String username = usernameEditText.getText().toString().trim();
                    String password = passwordEditText.getText().toString().trim();

                    // Input validation
                    if (username.isEmpty()) {
                        Toast.makeText(RegistrationActivity.this, "Please enter a username", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (password.isEmpty()) {
                        Toast.makeText(RegistrationActivity.this, "Please enter a password", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (username.length() < 3) {
                        Toast.makeText(RegistrationActivity.this, "Username must be at least 3 characters", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (password.length() < 6) {
                        Toast.makeText(RegistrationActivity.this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Add user to database
                    dbHelper.addUser(username, password);
                    Toast.makeText(RegistrationActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegistrationActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                })
        ).start());
    }

    /**
     * Sets the locale for the app based on saved preferences.
     */
    private void setLocale() {
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        String language = prefs.getString("My_Lang", "en"); // Default to English
        Locale locale = new Locale(language);
        Locale.setDefault(locale);

        // Update configuration
        getResources().getConfiguration().setLocale(locale);
        getResources().updateConfiguration(getResources().getConfiguration(), getResources().getDisplayMetrics());
    }
}











