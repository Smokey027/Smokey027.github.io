/**
 * Event.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Represents an Event object with ID, title, date, and location properties.
 * Serves as a model for event data.
 * Known Issues:
 * Data integrity needs to be addressed with validation logic within the class.
 * Functionality:
 * Provides a simple data structure for event information.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

public class Event {

    private final int id; // Unique identifier for the event
    private final String title; // Title of the event
    private final String date; // Date of the event
    private final String location; // Location of the event

    /**
     * Constructor to initialize an Event object with specified details.
     *
     * @param id The unique identifier for the event.
     * @param title The title of the event.
     * @param date The date of the event.
     * @param location The location where the event is held.
     */
    public Event(int id, String title, String date, String location) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.location = location;
    }

    /**
     * Gets the unique identifier of the event.
     *
     * @return The event ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Gets the title of the event.
     *
     * @return The event title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets the date of the event.
     *
     * @return The event date.
     */
    public String getDate() {
        return date;
    }

    /**
     * Gets the location of the event.
     *
     * @return The event location.
     */
    public String getLocation() {
        return location;
    }
}


