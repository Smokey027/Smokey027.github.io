/**
 * BaseActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.1
 * Purpose: Provides a base activity class that handles language settings for the application.
 * Allows for dynamic language changes and persists user language preferences.
 * Known Issues:
 * May require additional handling for configuration changes other than locale.
 * Functionality:
 * - Loads and applies saved language preferences on activity creation.
 * - Provides methods to change the language and restart the activity to apply changes.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Load the saved language preference from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        // Default language is set to English if no preference is found
        String language = prefs.getString("My_Lang", "en");
        // Apply the language setting
        setLocale(language);
        super.onCreate(savedInstanceState);
    }

    // Method to set the application's locale/language
    private void setLocale(String lang) {
        // Create a new Locale object with the specified language code
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        // Update the configuration with the new locale
        Configuration config = new Configuration(getResources().getConfiguration());
        config.setLocale(locale);

        // Create a new context with the updated configuration
        Context context = createConfigurationContext(config);
        // Update the resources with the new configuration
        getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }

    // Method to change the application's language and restart the activity
    protected void changeLanguage(String languageCode) {
        // Set the new locale using the specified language code
        setLocale(languageCode);

        // Save the selected language in SharedPreferences for persistence
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();

        // Restart the current activity to apply the language change
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
}




