/**
 * MainActivityTest.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.0
 * Purpose: Tests the login functionality of MainActivity using Espresso.
 * Known Issues: None identified.
 * Functionality:
 * - Simulates user interaction with the login UI.
 * - Validates behavior when invalid credentials are entered.
 * - Checks for appropriate toast message display upon login failure.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public ActivityScenarioRule<MainActivity> activityScenarioRule =
            new ActivityScenarioRule<>(MainActivity.class);

    /**
     * Tests the login button functionality with invalid credentials.
     * Simulates user input and checks for the correct error message.
     */
    @Test
    public void testLoginButton_withInvalidCredentials() {
        // Simulate entering invalid username and password
        onView(withId(R.id.usernameField)).perform(typeText("invalidUsername"));
        onView(withId(R.id.passwordField)).perform(typeText("invalidPassword"));

        // Click the login button
        onView(withId(R.id.loginButton)).perform(click());

        // Add a delay to ensure the toast is displayed
        try {
            Thread.sleep(2000); // 2 seconds delay to allow toast to appear
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Verify that a toast with the message "Invalid username or password" is displayed
        onView(withText("Invalid username or password"))
                .inRoot(ToastMatcher.isToast())
                .check(matches(withText("Invalid username or password")));
    }
}
