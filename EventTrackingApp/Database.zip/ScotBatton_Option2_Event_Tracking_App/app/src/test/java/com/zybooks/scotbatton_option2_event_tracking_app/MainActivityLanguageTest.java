/**
 * MainActivityLanguageTest.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: October 6, 2024
 * Version 1.0
 * Purpose: Tests the language change functionality in MainActivity using Robolectric and Mockito.
 * Known Issues: None identified.
 * Functionality:
 * - Initializes MainActivity in a test environment.
 * - Simulates changing the language preference.
 * - Verifies that the language preference is correctly saved in SharedPreferences.
 */

package com.zybooks.scotbatton_option2_event_tracking_app;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;

import android.content.Context;
import android.content.SharedPreferences;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 30, manifest = Config.NONE) // Specifies SDK version and no manifest
public class MainActivityLanguageTest {

    private MainActivity mainActivity;

    /**
     * Sets up the test environment before each test.
     * Initializes Mockito and creates an instance of MainActivity.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mainActivity = Robolectric.buildActivity(MainActivity.class).create().get();
    }

    /**
     * Tests the changeLanguage method to ensure it saves the correct language preference.
     */
    @Test
    public void testChangeLanguage_savesLanguagePreference() {
        // Prepare test data and environment
        String languageCode = "es"; // Spanish language code
        SharedPreferences sharedPreferences = mainActivity.getSharedPreferences("Settings", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Act: Change the language in MainActivity
        mainActivity.changeLanguage(languageCode);

        // Capture and verify the interactions with SharedPreferences.Editor
        ArgumentCaptor<String> captorKey = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> captorValue = ArgumentCaptor.forClass(String.class);
        verify(editor).putString(captorKey.capture(), captorValue.capture());
        verify(editor).apply();

        // Assert that the correct key-value pair was saved
        assertEquals("My_Lang", captorKey.getValue());
        assertEquals(languageCode, captorValue.getValue());
    }
}


