/**
 * Database.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: September 22, 2024
 * Version 1.1
 * Purpose: Manages SQLite database for application.
 * Creates table and CRUD operations for users and events
 * Known Issues:
 * Error logging could be improved for better debugging.
 * Functionality:
 * Defines database schema and handles database lifecycle
 * Provides methods for adding, updating, deleting, and retrieving data.
 * Implements password hashing for user security.
 */
package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import org.mindrot.jbcrypt.BCrypt;

public class DataBase extends SQLiteOpenHelper {

    // Constants for database name and version
    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names for the users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Table and column names for the events table
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_TITLE = "title";
    public static final String COLUMN_EVENT_DATE = "date";
    public static final String COLUMN_EVENT_LOCATION = "location";

    // Constructor to initialize the database helper
    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create the users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS +
                "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
                COLUMN_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUsersTable);

        // SQL statement to create the events table
        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS +
                "(" + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_TITLE + " TEXT, " +
                COLUMN_EVENT_DATE + " TEXT, " +
                COLUMN_EVENT_LOCATION + " TEXT)";
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if they exist and recreate them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    /**
     * Adds a new user to the database with a hashed password.
     * @param username The username of the user.
     * @param password The password of the user.
     */
    public void addUser(String username, String password) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            // Hash the password using BCrypt
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_PASSWORD, hashedPassword);
            db.insert(TABLE_USERS, null, values);
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error adding user", e);
        }
    }

    /**
     * Checks if the provided username and password match an existing user.
     * @param username The username to check.
     * @param password The password to check.
     * @return True if the user is authenticated, false otherwise.
     */
    public boolean checkUser(String username, String password) {
        boolean isAuthenticated = false;
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            // Query to find the user's hashed password
            Cursor cursor = db.rawQuery("SELECT " + COLUMN_PASSWORD + " FROM " + TABLE_USERS +
                    " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});

            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(0);
                // Check if the provided password matches the stored hash
                isAuthenticated = BCrypt.checkpw(password, storedHash);
            }
            cursor.close();
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error checking user", e);
        }
        return isAuthenticated;
    }

    /**
     * Adds a new event to the database with a transaction for better performance.
     * @param title The title of the event.
     * @param date The date of the event.
     * @param location The location of the event.
     */
    public void addEvent(String title, String date, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction(); // Start transaction
        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN_EVENT_TITLE, title);
            values.put(COLUMN_EVENT_DATE, date);
            values.put(COLUMN_EVENT_LOCATION, location);
            db.insert(TABLE_EVENTS, null, values);
            db.setTransactionSuccessful(); // Mark the transaction as successful
        } catch (SQLException e) {
            Log.e("Database Error", "Error adding event", e);
        } finally {
            db.endTransaction(); // End transaction
            db.close(); // Close the database
        }
    }

    /**
     * Deletes an event from the database by its ID with error handling.
     * @param eventId The ID of the event to delete.
     */
    public void deleteEvent(long eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction(); // Start transaction
        try {
            int rowsAffected = db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            if (rowsAffected == 0) {
                Log.e("Database Error", "No event found with ID: " + eventId);
            }
            db.setTransactionSuccessful(); // Mark the transaction as successful
        } catch (SQLException e) {
            Log.e("Database Error", "Error deleting event", e);
        } finally {
            db.endTransaction(); // End transaction
            db.close(); // Close the database
        }
    }

    /**
     * Retrieves all events from the database.
     * @return A Cursor object containing all events.
     */
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_EVENTS, null, null, null, null, null, null);
    }

    /**
     * Retrieves a paginated list of events from the database.
     * @param offset The starting point of the records to fetch.
     * @param limit The maximum number of records to fetch.
     * @return A Cursor object containing the events.
     */
    public Cursor getEventsPaginated(int offset, int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_EVENTS, null, null, null, null, null, null, offset + "," + limit);
    }

    /**
     * Updates an existing event in the database.
     * @param eventId The ID of the event to update.
     * @param title The new title of the event.
     * @param date The new date of the event.
     * @param location The new location of the event.
     */
    public void updateEvent(long eventId, String title, String date, String location) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_EVENT_TITLE, title);
            values.put(COLUMN_EVENT_DATE, date);
            values.put(COLUMN_EVENT_LOCATION, location);
            db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error updating event", e);
        }
    }
}



