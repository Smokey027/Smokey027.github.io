/**
 * MainActivity.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: September 22, 2024
 * Version 1.1
 * Purpose: Main entry point for the app.
 * Handles user authentication and navigation.
 * Manages SMS permissions
 * Known Issues:
 * Consider enhanced password policies
 * SMS functionality requires permission checks
 * Functionality:
 * Validates user credentials and navigates to EventListActivity
 * Requests SMS permissions and sends sample SMS
 * Provides navigation to RegistrationActivity
 */
package com.zybooks.scotbatton_option2_event_tracking_app;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Locale;

public class MainActivity extends BaseActivity {

    private EditText usernameField;
    private EditText passwordField;
    private DataBase dbHelper;
    private static final int SMS_PERMISSION_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DataBase(this);
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);
        Button buttonEnglish = findViewById(R.id.button_english);
        Button buttonSpanish = findViewById(R.id.button_spanish);


        loginButton.setOnClickListener(v -> {
            v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).withEndAction(() ->
                    v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).withEndAction(() -> {
                        String username = usernameField.getText().toString().trim();
                        String password = passwordField.getText().toString().trim();

                        if (username.isEmpty() || password.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (dbHelper.checkUser(username, password)) {
                            Intent intent = new Intent(MainActivity.this, EventListActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                        }
                    })
            ).start();
        });

        createAccountButton.setOnClickListener(v -> {
            v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).withEndAction(() ->
                    v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).withEndAction(() -> {
                        Intent intent = new Intent(MainActivity.this, RegistrationActivity.class);
                        startActivity(intent);
                    })
            ).start();
        });

        // Set up language buttons
        buttonEnglish.setOnClickListener(v -> changeLanguage("en"));
        buttonSpanish.setOnClickListener(v -> changeLanguage("es"));

        requestSmsPermission();

        // Set up bottom navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                Toast.makeText(MainActivity.this, "Home selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_events) {
                Toast.makeText(MainActivity.this, "Events selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.nav_profile) {
                Toast.makeText(MainActivity.this, "Profile selected", Toast.LENGTH_SHORT).show();
                return true;
            } else {
                return false;
            }
        });

        // Inflate the menu
        invalidateOptionsMenu(); // This will trigger onCreateOptionsMenu again
    }

    protected void changeLanguage(String languageCode) {
        setLocale(languageCode);

        // Save the selected language in SharedPreferences
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();

        // Restart the current activity to apply changes
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = getResources().getConfiguration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendSms();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSms();
            } else {
                Toast.makeText(this, "SMS permission denied. Some features may not work.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSms() {
        // Implement your SMS sending logic here
    }
}










