package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Load the saved language preference
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        String language = prefs.getString("My_Lang", "en"); // Default to English
        setLocale(language);
        super.onCreate(savedInstanceState);
    }

    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        // Update the configuration
        Configuration config = new Configuration(getResources().getConfiguration());
        config.setLocale(locale);

        // Create a new context with the updated configuration
        Context context = createConfigurationContext(config);
        getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }

    protected void changeLanguage(String languageCode) {
        setLocale(languageCode);

        // Save the selected language in SharedPreferences
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();

        // Restart the current activity to apply changes
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
}



