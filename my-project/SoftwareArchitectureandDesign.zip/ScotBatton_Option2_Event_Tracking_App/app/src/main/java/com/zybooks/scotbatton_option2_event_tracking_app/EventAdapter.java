/**
 * EventAdapter.java
 * Programmer: Scot C. Batton
 * Contact: saturdaynight135@gmail.com
 * Date: September 22, 2024
 * Version 1.1
 * Purpose: Binds a list of events to a RecyclerView.
 * Allows for display and interaction with event data in the UI.
 * Known Issues:
 * Could benefit from animations or transitions for better user experience
 * Functionality:
 * Inflates event items and binds data to views
 * Handles edit and delete actions through item buttons
 * Updates UI when events are modified
 */
package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private Context context;              // Context of the calling activity
    private List<Event> eventList;        // List of events to be displayed in the RecyclerView
    private DataBase dbHelper;            // Database helper for performing database operations

    /**
     * Constructor for EventAdapter.
     *
     * @param context The context of the calling activity.
     * @param eventList The list of events to be displayed.
     */
    public EventAdapter(Context context, List<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
        this.dbHelper = new DataBase(context);
    }

    /**
     * Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
     *
     * @param parent The ViewGroup into which the new View will be added after it is bound to an adapter position.
     * @param viewType The view type of the new View.
     * @return A new ViewHolder that holds a View of the given view type.
     */
    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each event item
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     *
     * @param holder The ViewHolder which should be updated to represent the contents of the item at the given position.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Get the event at the current position
        Event event = eventList.get(position);
        // Bind event details to the ViewHolder
        holder.titleTextView.setText(event.getTitle());
        holder.dateTextView.setText(event.getDate());
        holder.locationTextView.setText(event.getLocation());

        // Set click listener for the edit button
        holder.editButton.setOnClickListener(v -> {
            // Start EditEventActivity to edit the event
            Intent intent = new Intent(context, EditEventActivity.class);
            intent.putExtra("event_id", event.getId());
            context.startActivity(intent);
        });

        // Set click listener for the delete button
        holder.deleteButton.setOnClickListener(v -> {
            try {
                // Delete the event from the database
                dbHelper.deleteEvent(event.getId());
                // Remove the event from the list and notify the adapter
                eventList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, eventList.size());
                Toast.makeText(context, "Event deleted successfully", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(context, "Failed to delete event. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return eventList.size();
    }

    /**
     * ViewHolder class for holding the views for each event item.
     */
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView dateTextView;
        TextView locationTextView;
        Button editButton;
        Button deleteButton;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            locationTextView = itemView.findViewById(R.id.locationTextView);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}



