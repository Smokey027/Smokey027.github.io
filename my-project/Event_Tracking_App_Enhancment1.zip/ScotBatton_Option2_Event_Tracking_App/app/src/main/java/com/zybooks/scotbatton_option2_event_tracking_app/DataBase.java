package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import org.mindrot.jbcrypt.BCrypt;

public class DataBase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_TITLE = "title";
    public static final String COLUMN_EVENT_DATE = "date";
    public static final String COLUMN_EVENT_LOCATION = "location";

    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS +
                "(" + COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_USERNAME + " TEXT, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS +
                "(" + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_EVENT_TITLE + " TEXT, " +
                COLUMN_EVENT_DATE + " TEXT, " +
                COLUMN_EVENT_LOCATION + " TEXT)";
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public void addUser(String username, String password) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_PASSWORD, hashedPassword);
            db.insert(TABLE_USERS, null, values);
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error adding user", e);
        }
    }

    public boolean checkUser(String username, String password) {
        boolean isAuthenticated = false;
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT " + COLUMN_PASSWORD + " FROM " + TABLE_USERS +
                    " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});

            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(0);
                isAuthenticated = BCrypt.checkpw(password, storedHash);
            }
            cursor.close();
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error checking user", e);
        }
        return isAuthenticated;
    }

    public void addEvent(String title, String date, String location) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_EVENT_TITLE, title);
            values.put(COLUMN_EVENT_DATE, date);
            values.put(COLUMN_EVENT_LOCATION, location);
            db.insert(TABLE_EVENTS, null, values);
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error adding event", e);
        }
    }

    public void deleteEvent(long eventId) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error deleting event", e);
        }
    }

    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_EVENTS, null, null, null, null, null, null);
    }

    public void updateEvent(long eventId, String title, String date, String location) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_EVENT_TITLE, title);
            values.put(COLUMN_EVENT_DATE, date);
            values.put(COLUMN_EVENT_LOCATION, location);
            db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            db.close();
        } catch (SQLException e) {
            Log.e("Database Error", "Error updating event", e);
        }
    }
}
