package com.zybooks.scotbatton_option2_event_tracking_app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.zybooks.scotbatton_option2_event_tracking_app.R;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.zybooks.scotbatton_option2_event_tracking_app.R;

public class EventListActivity extends AppCompatActivity {

    private DataBase dbHelper;
    private EventAdapter eventAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        dbHelper = new DataBase(this);
        dbHelper.getWritableDatabase();

        displayRecyclerView();


    }

    private void displayRecyclerView() {
        Cursor cursor = dbHelper.getAllEvents();

        RecyclerView recyclerView = findViewById(R.id.eventRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        eventAdapter = new EventAdapter(this, cursor);
        recyclerView.setAdapter(eventAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        dbHelper.getWritableDatabase();
        displayRecyclerView();
    }

    @Override
    protected void onPause() {
        dbHelper.close();
        super.onPause();
    }

    private class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

        private Context context;
        private Cursor cursor;

        public EventAdapter(Context context, Cursor cursor) {
            this.context = context;
            this.cursor = cursor;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.event_info, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if (cursor.moveToPosition(position)) {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_TITLE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_DATE));
                String location = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_LOCATION));

                holder.titleTextView.setText(title);
                holder.dateTextView.setText(date);
                holder.locationTextView.setText(location);
            }
        }

        @Override
        public int getItemCount() {
            return cursor.getCount();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView titleTextView;
            public TextView dateTextView;
            public TextView locationTextView;

            public ViewHolder(View itemView) {
                super(itemView);
                titleTextView = itemView.findViewById(R.id.titleTextView);
                dateTextView = itemView.findViewById(R.id.dateTextView);
                locationTextView = itemView.findViewById(R.id.locationTextView);

                itemView.setOnClickListener(v -> {
                    int position = getAdapterPosition();
                    if (cursor.moveToPosition(position)) {
                        String eventName = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.COLUMN_EVENT_TITLE));
                        Toast.makeText(context, eventName, Toast.LENGTH_SHORT).show();
                    }
                });

                itemView.setOnLongClickListener(v -> {
                    int position = getAdapterPosition();
                    if (cursor.moveToPosition(position)) {
                        final long deleteId = cursor.getLong(cursor.getColumnIndexOrThrow(DataBase.COLUMN_ID));
                        new AlertDialog.Builder(EventListActivity.this)
                                .setTitle("Delete Event")
                                .setMessage("Are you sure you want to delete this event?")
                                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                                    dbHelper.deleteEvent((int) deleteId);
                                    displayRecyclerView(); // Refresh the list after deletion
                                })
                                .setNegativeButton(android.R.string.no, null)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                    }
                    return true;
                });
            }
        }
    }
}




