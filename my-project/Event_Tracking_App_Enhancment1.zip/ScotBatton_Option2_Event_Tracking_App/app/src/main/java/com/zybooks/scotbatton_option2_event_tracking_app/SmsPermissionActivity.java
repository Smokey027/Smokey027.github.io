package com.zybooks.scotbatton_option2_event_tracking_app;

import android.app.Activity;

public class SmsPermissionActivity extends Activity {
}
