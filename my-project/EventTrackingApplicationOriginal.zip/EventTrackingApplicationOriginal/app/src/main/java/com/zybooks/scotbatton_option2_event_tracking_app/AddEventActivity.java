package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zybooks.scotbatton_option2_event_tracking_app.R;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText titleEditText;
    private EditText dateEditText;
    private EditText locationEditText;
    private Button saveEventButton;
    private DataBase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        dbHelper = new DataBase(this);

        titleEditText = findViewById(R.id.titleEditText);
        dateEditText = findViewById(R.id.dateEditText);
        locationEditText = findViewById(R.id.locationEditText);
        saveEventButton = findViewById(R.id.saveEventButton);

        saveEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString().trim();
                String date = dateEditText.getText().toString().trim();
                String location = locationEditText.getText().toString().trim();

                if (!title.isEmpty() && !date.isEmpty() && !location.isEmpty()) {
                    dbHelper.addEvent(title, date, location);
                    Toast.makeText(AddEventActivity.this, "Event added", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(AddEventActivity.this, EventListActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(AddEventActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}


